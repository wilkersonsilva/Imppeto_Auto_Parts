// main.js (Ponto de Entrada Principal - Completo e Atualizado)
// Data da Última Atualização: 18 de maio de 2025 (BRT)

// --- Utilitários e Carregadores Principais ---
import { initializeTheme, loadHTML, closeModal, initializeTabs } from './uiUtils.js';
import { loadContent, sectionTitles, getCurrentSection } from './contentLoader.js';
import { initializeSidebarInteractions } from './sidebarController.js';
import { initializeTopNavInteractions } from './topnavController.js';

// --- Controllers Específicos de Seção (Importando funções de inicialização e globais) ---
import { initializeDashboard } from './dashboardController.js';
import { openModalNovoCliente, visualizarCliente, editarCliente, excluirCliente, buscarCep } from './clientesController.js';
import { initializePecas, openModalNovaPeca, visualizarPeca, editarPeca, excluirPeca } from './pecasController.js';
import { initializeFornecedores, openModalNovoFornecedor, visualizarFornecedor, editarFornecedor, excluirFornecedor, buscarCepFornecedor } from './fornecedoresController.js';
import { initializeEntradaPecas, removerItemEntrada, cancelarNovaEntrada, visualizarDetalhesEntrada } from './entradaPecasController.js';
import { initializeSaidaPecas, removerItemSaida as removerItemTabelaSaida, cancelarNovaSaida as cancelarFormSaida, visualizarDetalhesSaida as verDetalhesSaida } from './saidaPecasController.js';
import { initializeInventario, visualizarMovimentacoesPeca, realizarAjusteEstoque, iniciarProcessoContagem, exportarInventario } from './inventarioController.js';
import { initializeGarantiaValidade, ajustarEstoquePorValidade, registrarAcionamentoGarantia, visualizarDetalhesGarantia } from './garantiaValidadeController.js';
import { initializePedidoVenda, removerItemDoPedido, cancelarNovoPedidoVenda, salvarPedidoComoOrcamento, listarPedidosVenda, imprimirOrcamentoVenda } from './pedidoVendaController.js';
import { initializeEmissaoNf, carregarDadosDoPedidoParaNFe, limparFormularioNFe, validarESimularEnvioNFe, listarNotasFiscais, adicionarItemManualmenteNFe, imprimirDANFESimulado } from './emissaoNfController.js';
import { initializeComissoes, processarPagamentoComissoesSelecionadas, exportarRelatorioComissoes } from './comissoesController.js';
import { initializeUsuariosPerfis, openModalNovoUsuario, editarUsuario, resetarSenhaUsuario, alternarStatusUsuario, openModalNovoPerfil, editarPerfil, excluirPerfil } from './usuariosController.js';
import { initializePreferencias, buscarCepPreferencias } from './preferenciasController.js';
import { initializeCurvaABC, exportarAnaliseABC, acaoVerDetalhesPecaABC, acaoVerEstoquePecaABC, acaoSugerirCompraPecaABC } from './curvaAbcController.js';


// --- FUNÇÃO DE LOGOUT ---
function logout() {
    if (confirm("Tem certeza que deseja sair do sistema?")) {
        localStorage.removeItem('usuarioLogadoImppeto');
        // Garante que está redirecionando para o arquivo correto na raiz
        const basePath = window.location.pathname.substring(0, window.location.pathname.lastIndexOf('/') + 1);
        window.location.href = basePath + 'login.html';
    }
}
// -------------------------


// --- Ponto de Partida da Aplicação ---
document.addEventListener('DOMContentLoaded', () => {
    // Verifica se está na página de login para não executar lógica do painel
    if (window.location.pathname.includes('login.html')) {
        // Lógica específica para a página de login, se houver (já está no script embutido de login.html)
        console.log("Página de login carregada.");
        return;
    }

    // **VERIFICAÇÃO DE AUTENTICAÇÃO PARA O PAINEL PRINCIPAL**
    const usuarioLogadoString = localStorage.getItem('usuarioLogadoImppeto');
    let usuarioLogado = null;

    if (usuarioLogadoString) {
        try {
            usuarioLogado = JSON.parse(usuarioLogadoString);
        } catch (e) {
            console.error("Erro ao parsear dados do usuário logado do localStorage:", e);
            localStorage.removeItem('usuarioLogadoImppeto'); // Limpa dados inválidos
        }
    }

    if (!usuarioLogado) {
        // Se não houver usuário logado, redireciona para a página de login
        const basePath = window.location.pathname.substring(0, window.location.pathname.lastIndexOf('/') + 1);
        window.location.href = basePath + 'login.html';
        return; // Impede a execução do restante do script do painel
    }

    console.log("Usuário logado (simulação):", usuarioLogado);

    // Expondo funções globais para onclicks e utilidades gerais
    window.loadContent = loadContent;
    window.closeModal = closeModal;
    window.initializeTabs = initializeTabs;

    // Clientes
    window.openModalNovoCliente = openModalNovoCliente;
    window.visualizarCliente = visualizarCliente;
    window.editarCliente = editarCliente;
    window.excluirCliente = excluirCliente;
    window.buscarCep = buscarCep;

    // Peças
    window.openModalNovaPeca = openModalNovaPeca;
    window.visualizarPeca = visualizarPeca;
    window.editarPeca = editarPeca;
    window.excluirPeca = excluirPeca;

    // Fornecedores
    window.openModalNovoFornecedor = openModalNovoFornecedor;
    window.visualizarFornecedor = visualizarFornecedor;
    window.editarFornecedor = editarFornecedor;
    window.excluirFornecedor = excluirFornecedor;
    window.buscarCepFornecedor = buscarCepFornecedor;

    // Entrada de Peças
    window.removerItemEntrada = removerItemEntrada;
    window.cancelarNovaEntrada = cancelarNovaEntrada;
    window.visualizarDetalhesEntrada = visualizarDetalhesEntrada;

    // Saída de Peças
    window.removerItemSaida = removerItemTabelaSaida;
    window.cancelarNovaSaida = cancelarFormSaida;
    window.visualizarDetalhesSaida = verDetalhesSaida;

    // Inventário
    window.visualizarMovimentacoesPeca = visualizarMovimentacoesPeca;
    window.realizarAjusteEstoque = realizarAjusteEstoque;
    window.iniciarProcessoContagem = iniciarProcessoContagem;
    window.exportarInventario = exportarInventario;

    // Garantia e Validade
    window.ajustarEstoquePorValidade = ajustarEstoquePorValidade;
    window.registrarAcionamentoGarantia = registrarAcionamentoGarantia;
    window.visualizarDetalhesGarantia = visualizarDetalhesGarantia;

    // Pedido de Venda
    window.removerItemDoPedido = removerItemDoPedido;
    window.cancelarNovoPedidoVenda = cancelarNovoPedidoVenda;
    window.salvarPedidoComoOrcamento = salvarPedidoComoOrcamento;
    window.listarPedidosVenda = listarPedidosVenda;
    window.imprimirOrcamentoVenda = imprimirOrcamentoVenda;

    // Emissão NF-e
    window.carregarDadosDoPedidoParaNFe = carregarDadosDoPedidoParaNFe;
    window.limparFormularioNFe = limparFormularioNFe;
    window.validarESimularEnvioNFe = validarESimularEnvioNFe;
    window.listarNotasFiscais = listarNotasFiscais;
    window.adicionarItemManualmenteNFe = adicionarItemManualmenteNFe;
    window.imprimirDANFESimulado = imprimirDANFESimulado;

    // Comissões
    window.processarPagamentoComissoesSelecionadas = processarPagamentoComissoesSelecionadas;
    window.exportarRelatorioComissoes = exportarRelatorioComissoes;

    // Usuários e Perfis
    window.openModalNovoUsuario = openModalNovoUsuario;
    window.editarUsuario = editarUsuario;
    window.resetarSenhaUsuario = resetarSenhaUsuario;
    window.alternarStatusUsuario = alternarStatusUsuario;
    window.openModalNovoPerfil = openModalNovoPerfil;
    window.editarPerfil = editarPerfil;
    window.excluirPerfil = excluirPerfil;

    // Preferências da Loja
    window.buscarCepPreferencias = buscarCepPreferencias;

    // Curva ABC
    window.exportarAnaliseABC = exportarAnaliseABC;
    window.acaoVerDetalhesPecaABC = acaoVerDetalhesPecaABC;
    window.acaoVerEstoquePecaABC = acaoVerEstoquePecaABC;
    window.acaoSugerirCompraPecaABC = acaoSugerirCompraPecaABC;

    // Logout
    window.logout = logout;


    // Inicialização da Aplicação do Painel
    initializeTheme();
    loadLayoutComponents(usuarioLogado); // Passa o usuário logado para o layout
    loadContent('dashboard'); // Carrega a seção inicial
});

/**
 * Carrega os componentes de layout principais (sidebar e topnav) e inicializa suas interações.
 * @param {object} [usuario] - O objeto do usuário logado.
 */
async function loadLayoutComponents(usuario) {
    // Carrega o HTML da sidebar e da topnav em paralelo
    await Promise.all([
        loadHTML('_sidebar.html', 'sidebar-container', () => initializeSidebarInteractions(usuario)),
        loadHTML('_top_navigation.html', 'topnav-container', () => initializeTopNavInteractions(usuario)) // Passar usuário aqui também se a topnav precisar
    ]);
}